﻿using System.ComponentModel.DataAnnotations;

namespace SampleAPI.Entities
{
    public class Order
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(100)]
        public string ?Name { get; set; }
        [Required]
        [MaxLength(100)]
        public string ?Description { get; set; }
        [Required]
        public DateTime CreatedDate { get; set; }
        [Required]
        public bool IsInvoiced {get;set;} = true;
        [Required]
        public bool IsDeleted { get; set; } = false;
    }
}
