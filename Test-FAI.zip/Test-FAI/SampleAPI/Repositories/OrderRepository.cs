﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SampleAPI.Entities;
using SampleAPI.Requests;

namespace SampleAPI.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        /// <summary>
        /// Injecting DB Context dependency
        /// </summary>
        private readonly SampleApiDbContext _context;
        public OrderRepository(SampleApiDbContext context)
        {
            _context = context;
        }
      
        /// <summary>
        /// Get the list of recent orders
        /// </summary>
        /// <returns></returns>
        public async Task<ActionResult<IEnumerable<Order>>> GetRecentOrdersAsync()
        {            
            return  await _context.Orders.Where(x => x.IsDeleted == false && x.CreatedDate >= DateTime.Now.AddDays(-1)).OrderByDescending(x => x.CreatedDate).ToListAsync();
        }

        /// <summary>
        /// Post an order request
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        public async Task<ActionResult<Order>> PostOrderAsync(Order order)
        {
            _context.Orders.Add(order);
            await _context.SaveChangesAsync();
            return order;
        }


    }
}
