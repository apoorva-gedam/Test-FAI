﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Requests;
using System;

namespace SampleAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderRepository _orderRepository;

        private readonly ILogger _logger;
        
        // Add more dependencies as needed.

        public OrdersController(IOrderRepository orderRepository,ILogger logger)
        {
            _orderRepository = orderRepository;
            _logger = logger;
          
        }        
        /// <summary>
        /// Get Recent Orders list
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]// TODO: Add all response types
        public async Task<ActionResult<List<Order>>> GetRecentOrdersList()
        {
            try
            {
                return Ok(await _orderRepository.GetRecentOrdersAsync());
            }
            catch (Exception ex)
            {
                _logger.LogError("Something unexpected happened" + ex);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        /// <summary>
        /// Post new order
        /// </summary>
        /// <param name="orderRequest"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> PostNewOrder(CreateOrderRequest orderRequest)
        {
            try
            {
                if (orderRequest == null)
                {
                    _logger.LogError("orderRequest is empty or null");
                    return BadRequest();
                }
                var order = new Order
                {
                    Name = orderRequest.Name,
                    Description = orderRequest.Description,
                    IsInvoiced = orderRequest.IsInvoiced,
                    CreatedDate = DateTime.Now
                };
                await _orderRepository.PostOrderAsync(order);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("Something unexpected happened" + ex);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
            
        }

        /// TODO: Add an endpoint to allow users to create an order using <see cref="CreateOrderRequest"/>.
    }
}
