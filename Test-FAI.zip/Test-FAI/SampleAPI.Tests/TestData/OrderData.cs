﻿using SampleAPI.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleAPI.Tests.TestData
{
    internal class OrderData
    {
        public List<Order> GetOrderData()
        {
            List<Order> OrderData = new List<Order>
        {
            new Order
            {
                Id = 1,
                Name = "IPhone",
                Description = "IPhone 12",
                CreatedDate = DateTime.Now,
                IsInvoiced = true,
                IsDeleted = false,
            },
             new Order
            {
               Id = 2,
                Name = "Samsung",
                Description = "Samsung Galaxy",
                CreatedDate = DateTime.Now,
                IsInvoiced = true,
                IsDeleted = false,
            },
             new Order
            {
                Id = 3,
                Name = "OnePlus",
                Description = "OnePlus Nord",
                CreatedDate = DateTime.Now,
                IsInvoiced = true,
                IsDeleted = false,
            },
        };
            return OrderData;
        }
    }
}
