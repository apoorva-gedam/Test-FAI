using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Tests.TestData;

namespace SampleAPI.Tests.Repositories
{

    public class OrderRepositoryTests 
    {
        [Fact]

        public async Task GetRecentOrdersAsync_Retuns_ListOfOrders()
        {
            //Arrange
            var orderData = new OrderData();
            var context = MockSampleApiDbContextFactory.GenerateMockContext();
            var repository  = new OrderRepository(context);
            var testOrders = orderData.GetOrderData();

            await context.SaveChangesAsync();
            context.Orders.AddRange(testOrders);
            await context.SaveChangesAsync();

            //Act

            var result = await repository.GetRecentOrdersAsync();

            //Assert

            Assert.NotNull(result);
            Assert.Equal(3,testOrders.Count);

        }

        [Fact]

        public async Task PostOrderAsync_Returns_OrderObject()
        {
            //Arrange
            var context = MockSampleApiDbContextFactory.GenerateMockContext();
            var repository = new OrderRepository(context);
            var postOrder = new Order { Id = 100,Name = "Redmi", Description = "Redmi X10", IsInvoiced = true,IsDeleted = false };
            await context.SaveChangesAsync();
            context.Orders.RemoveRange(context.Orders);
            await context.SaveChangesAsync();

            //Act
            var postResult = await repository.PostOrderAsync(postOrder);

            //Assert

            Assert.NotNull(postResult);
            Assert.Equal(postOrder,postResult.Value);

        }

        // TODO: Write repository unit tests
    }
}