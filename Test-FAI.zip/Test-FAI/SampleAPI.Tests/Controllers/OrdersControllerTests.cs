﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using SampleAPI.Controllers;
using SampleAPI.Entities;
using SampleAPI.Repositories;
using SampleAPI.Requests;
using SampleAPI.Tests.TestData;


namespace SampleAPI.Tests.Controllers
{
    public class OrdersControllerTests
    {
        // TODO: Write controller unit tests

        [Fact]
        public async Task GetRecentOrdersList_Returns_StatusCode200()
        {
            //Arrange
            OrderData orderData = new OrderData();
            var mockRepo = new Mock<IOrderRepository>();
            var mockLogger = new Mock<ILogger>();
            mockRepo.Setup(repo => repo.GetRecentOrdersAsync()).ReturnsAsync(orderData.GetOrderData());

            var controller = new OrdersController(mockRepo.Object,mockLogger.Object);

            //Act

            var result = await controller.GetRecentOrdersList();

            //Assert
            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            okResult.StatusCode = 200;
        }

        [Fact]
        public async Task GetRecentOrderList_Returns_AlistOfOrders()
        {
            //Arrange
            OrderData orderData = new OrderData();
           
            var mockRepo = new Mock<IOrderRepository>();
            var mockLogger = new Mock<ILogger>();
            mockRepo.Setup(repo => repo.GetRecentOrdersAsync()).ReturnsAsync(orderData.GetOrderData());

            var controller = new OrdersController(mockRepo.Object, mockLogger.Object);

            //Act
            var result = await controller.GetRecentOrdersList();
            //Assert
            var orderList = Assert.IsType<List<OrderData>>(result.Result);
            Assert.Equal(3, orderList.Count);

        }

        [Fact]

        public async Task PostNewOrder_Returns_StatusCode201()
        {
            //Arrange
           var mockRepo = new Mock<IOrderRepository>();
            var mockLogger = new Mock<ILogger>();

            mockRepo.Setup(repo => repo.PostOrderAsync(It.IsAny<Order>()));

            var controller = new OrdersController(mockRepo.Object, mockLogger.Object);

            //Act

            var result = await controller.PostNewOrder(new CreateOrderRequest
            {
                Name = "Test",
                Description = "Test Description",             
                IsInvoiced = false,
            });

            //Assert

            var okResult = Assert.IsType<OkObjectResult>(result);
            okResult.StatusCode = 201;

        }

        [Fact]
        public async Task PostNewOrder_With_Empty_Object_Returns_BadRequest()
        {
            //Arrange
            var mockRepo = new Mock<IOrderRepository>();
            var mockLogger = new Mock<ILogger>();

            mockRepo.Setup(repo => repo.PostOrderAsync(It.IsAny<Order>()));

            var controller = new OrdersController(mockRepo.Object, mockLogger.Object);

            //Act

            var result = await controller.PostNewOrder(null);

            //Assert

            var okResult = Assert.IsType<BadRequestResult>(result);
            
        }


    }
}
